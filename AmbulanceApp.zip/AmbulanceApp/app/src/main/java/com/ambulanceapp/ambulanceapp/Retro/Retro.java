package com.ambulanceapp.ambulanceapp.Retro;

import android.content.Context;
import android.util.Log;

import com.ambulanceapp.ambulanceapp.Prefrences.SharePrefrences;
import com.ambulanceapp.ambulanceapp.Responses.GenralResponse;
import com.ambulanceapp.ambulanceapp.Responses.GetAmbulanceResponse;
import com.ambulanceapp.ambulanceapp.Responses.GetIssueResponse;
import com.ambulanceapp.ambulanceapp.Responses.GetPatientResponse;
import com.ambulanceapp.ambulanceapp.Responses.LoginResponse;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.http.Field;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

public class Retro {

    public static String BASE_URL = "http://137.59.66.197:8081/PIS/API.asmx/";



    public static RestAdapter getClient(Context context) {

        SharePrefrences shareprefrance = new SharePrefrences();
        BASE_URL = "http://" + shareprefrance.getServerURL(context) + "/api.asmx/";

        Log.e("Retro", " BASE URL AS " + BASE_URL);

        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(BASE_URL)
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();
        return adapter;
    }



    public static Retrointerface getInterface(Context context) {
        return getClient(context).create(Retrointerface.class);
    }


    public interface Retrointerface{

        @FormUrlEncoded
        @POST("/loginAmbulance")
        public void loginAmbulance(
                @Field("Mobile") String Mobile,
                @Field("Password") String password,
                Callback<LoginResponse> response);


        @FormUrlEncoded
        @POST("/registerUser")
        public void registerUser(
                @Field("password") String password,
                @Field("name") String name,
                @Field("phone") String phone,
                @Field("address") String address,
                Callback<GenralResponse> response);


        @FormUrlEncoded
        @POST("/updateLocationAmbulance")
        public void updateLocation(
                @Field("id") int id,
                @Field("lat") double name,
                @Field("lng") double phone,
                Callback<GenralResponse> response);


        @FormUrlEncoded
        @POST("/GetPatient")
        public void GetPatient(
                @Field("id") int id,
                Callback<GetPatientResponse> response);

        @FormUrlEncoded
        @POST("/needHelp")
        public void needHelp(
                @Field("id") int id,
                Callback<GetIssueResponse> response);


        @FormUrlEncoded
        @POST("/GetAmbulance")
        public void GetAmbulance(
                @Field("userId") String id,
                Callback<GetAmbulanceResponse> response);










    }
}
