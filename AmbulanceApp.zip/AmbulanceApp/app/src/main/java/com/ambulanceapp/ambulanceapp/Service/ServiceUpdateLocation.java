package com.ambulanceapp.ambulanceapp.Service;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.ambulanceapp.ambulanceapp.Activity.HomeActivity;
import com.ambulanceapp.ambulanceapp.Prefrences.SharePrefrences;
import com.ambulanceapp.ambulanceapp.R;
import com.ambulanceapp.ambulanceapp.Responses.GenralResponse;
import com.ambulanceapp.ambulanceapp.Responses.GetIssueResponse;
import com.ambulanceapp.ambulanceapp.Responses.GetPatientResponse;
import com.ambulanceapp.ambulanceapp.Retro.Retro;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by fabio on 30/01/2016.
 */
public class ServiceUpdateLocation extends Service implements LocationListener {
    private LocationManager locationManager;
       private Timer timer;
    private TimerTask timerTask;


    //---------------------------------------------------------------------------------------
    public ServiceUpdateLocation(Context applicationContext) {
        super();
        Log.e("ServiceAtul", "here I am!");
    }

    public ServiceUpdateLocation() {
    }

    //---------------------------------------------------------------------------------------
    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("ServiceAtul", "here I am!");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        locationManager = (LocationManager) ServiceUpdateLocation.this.getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);

        startTimer();
        Log.e("ServiceAtul", "UpdateLocation Called");
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("ServiceAtul", "ondestroy!");
        Intent broadcastIntent = new Intent("uk.ac.shef.oak.ActivityRecognition.RestartSensor");
        sendBroadcast(broadcastIntent);
        locationManager.removeUpdates(this);
        stoptimertask();
    }

    public void startTimer() {
        //set a new Timer
        timer = new Timer();

        //initialize the TimerTask's job
        initializeTimerTask();

        //schedule the timer, to wake up every 10 minutus
        timer.schedule(timerTask, 1000, 3000); //
    }

    void updateLocation()
    {
        if(latitude!=0)
        {
            final int UserId = Integer.parseInt(getSharedPreferences("key_prefereance", MODE_PRIVATE).getString("key_id", "-1"));
            Retro.getInterface(ServiceUpdateLocation.this).updateLocation(UserId, latitude,longitude,new Callback<GenralResponse>() {
                @Override
                public void success(GenralResponse GenResponse, Response response) {
                    System.out.println(GenResponse.getStatus());
                    if (GenResponse.getStatus().equals("Success")) {

                    }
                    else {
                        //Toast.makeText(ServiceUpdateLocation.this, "Login Failed", Toast.LENGTH_SHORT).show();

                        // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                    }
                }
                @Override
                public void failure(RetrofitError error) {
                }
            });
        }
    }

    void GetIssues()
    {
        final int UserId = Integer.parseInt(getSharedPreferences("key_prefereance", MODE_PRIVATE).getString("key_id", "-1"));
        Retro.getInterface(ServiceUpdateLocation.this).GetPatient(UserId,new Callback<GetPatientResponse>() {
            @Override
            public void success(GetPatientResponse GenResponse, Response response) {
                System.out.println(GenResponse.getStatus());
                if (GenResponse.getStatus().equals("Success")) {
//                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
//                    Date date = new Date();
//                    SharePrefrences.setSosTime(ServiceUpdateLocation.this ,formatter.format(date));;
//                    SharePrefrences.setIsSkipped(ServiceUpdateLocation.this, false);
                    addNotification("Help Requested","Patient need help near you",GenResponse);

                }
                else {
                    //Toast.makeText(ServiceUpdateLocation.this, "API issue for GetIssue", Toast.LENGTH_SHORT).show();
                    // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                }
            }
            @Override
            public void failure(RetrofitError error) {
                Toast.makeText(ServiceUpdateLocation.this, "API issue for GetIssue", Toast.LENGTH_SHORT).show();
            }
        });
    }



    public void initializeTimerTask() {
        timerTask = new TimerTask() {
            public void run() {
            try
            {
                updateLocation();
                GetIssues();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            }
        };
    }

    private void addNotification(String title, String Text,GetPatientResponse genResponse) {
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.drawable.health_alert)
                        .setContentTitle(title)
                        .setContentText(Text);

        Intent notificationIntent = new Intent(this, HomeActivity.class);
        notificationIntent.putExtra("fromNotification", true);
        notificationIntent.putExtra("Id", genResponse.getUserId());
        notificationIntent.putExtra("userLat", genResponse.getUserLat());
        notificationIntent.putExtra("userLng", genResponse.getUserLng());
        notificationIntent.putExtra("hosLat", genResponse.getHosLat());
        notificationIntent.putExtra("hosLng", genResponse.getHosLng());

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(contentIntent);

        // Add as notification
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        //notificationIntent.putExtra("Id", 0);
        manager.notify(0, builder.build());

    }

    /**
     * not needed
     */
    public void stoptimertask() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Date yesterday() {
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }

    private double speed=0, latitude=0.0, longitude=0.0;
    // This method is called whenever new location data is available
    @Override
    public void onLocationChanged(Location location) {

        Log.e("Location","Location updated");
        // get location data
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        speed =(location.getSpeed())*(18/5);
        //txtSpeed.setText(Math.round( speed)+" Kmph");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onProviderEnabled(String provider) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onProviderDisabled(String provider) {
        // TODO Auto-generated method stub
    }

    float potholeWarningDistance = 20.0f;
    private static int counter;
    TextToSpeech tts;
}