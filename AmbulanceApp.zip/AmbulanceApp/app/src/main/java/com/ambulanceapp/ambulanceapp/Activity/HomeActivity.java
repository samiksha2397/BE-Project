package com.ambulanceapp.ambulanceapp.Activity;

import android.Manifest;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.ambulanceapp.ambulanceapp.Prefrences.SharePrefrences;
import com.ambulanceapp.ambulanceapp.R;
import com.ambulanceapp.ambulanceapp.Responses.GetAmbulanceResponse;
import com.ambulanceapp.ambulanceapp.Responses.GetIssueResponse;
import com.ambulanceapp.ambulanceapp.Retro.Retro;
import com.ambulanceapp.ambulanceapp.Service.ServiceUpdateLocation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class HomeActivity extends AppCompatActivity {


    private HomeActivity context;
    int secsRemaining=0;
    Button btnNavigateToPatient;
    Button btnNavigateToHospital;
    private String userLat;
    private String userLng;
    private String hosLat;
    private String hosLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        context=HomeActivity.this;




        if (getIntent().getExtras() != null) {
            Bundle b = getIntent().getExtras();
            boolean cameFromNotification = b.getBoolean("fromNotification");
           String SOSId= b.getString("fromNotification");
            userLat= b.getString("userLat");
            userLng= b.getString("userLng");
            hosLat= b.getString("hosLat");
            hosLng= b.getString("hosLng");
            if(cameFromNotification)
            {
                String ns = Context.NOTIFICATION_SERVICE;
                NotificationManager nMgr = (NotificationManager) HomeActivity.this.getSystemService(ns);
                nMgr.cancel(0);
            }
        }
        else
        {



            startService(new Intent(HomeActivity.this, ServiceUpdateLocation.class));
            finish();
        }


        btnNavigateToPatient = (Button) findViewById(R.id.btnNavigateToPatient);
        btnNavigateToHospital = (Button) findViewById(R.id.btnNavigateToHospital);


        btnNavigateToPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Destination= getIntent().getStringExtra("Destination");
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("http://maps.google.com/maps?daddr=" +userLat+","+userLng));
                        //Uri.parse("https://www.google.com/maps/dir/" +ViaPoints));
                        HomeActivity.this.startActivity(intent);
                        btnNavigateToHospital.setEnabled(true);
            }
        });



        btnNavigateToHospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Destination= getIntent().getStringExtra("Destination");
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("http://maps.google.com/maps?daddr=" +hosLat+","+hosLng));
                //Uri.parse("https://www.google.com/maps/dir/" +ViaPoints));
                HomeActivity.this.startActivity(intent);
            }
        });
    }



    void ReportSOS()
    {
        final int UserId = Integer.parseInt(getSharedPreferences("key_prefereance", MODE_PRIVATE).getString("key_id", "-1"));
        Retro.getInterface(HomeActivity.this).needHelp(UserId,new Callback<GetIssueResponse>() {
            @Override
            public void success(GetIssueResponse GenResponse, Response response) {
                System.out.println(GenResponse.getStatus());
                if (GenResponse.getStatus().equals("Success")) {
                    Toast.makeText(HomeActivity.this, "Help Requested", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(HomeActivity.this, "API issue for SOS", Toast.LENGTH_SHORT).show();

                    // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                }
            }
            @Override
            public void failure(RetrofitError error) {
            }
        });
    }

    ProgressDialog progressDialog;
    private void GetAmbulance() {
        if(progressDialog==null)
        {
            progressDialog=new ProgressDialog(HomeActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }
        try
        {
            String UserId=SharePrefrences.getUserId(HomeActivity.this);
            Retro.getInterface(HomeActivity.this).GetAmbulance(UserId,new Callback<GetAmbulanceResponse>() {
                @Override
                public void success(GetAmbulanceResponse RResponse, Response response) {

                    System.out.println(RResponse.getStatus());
                    if (RResponse.getStatus().equals("Success")&&RResponse.getAmbulanceAssigned()!=null) {
                        progressDialog.dismiss();
                        //startActivity(new Intent(HomeActivity.this, AmbulanceActivity.class));
                        finish();
                    }
                    else {
                        final Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // Do something after 5s = 5000ms
                                GetAmbulance();
                            }
                        }, 2000);

                        //progressDialog.dismiss();
                        // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    progressDialog.dismiss();
                    Toast.makeText(HomeActivity.this, "Check API", Toast.LENGTH_SHORT).show();
                }
            });

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }



}
