package com.ambulanceapp.ambulanceapp.Responses;

public class GetIssueResponse {

    private String Status;

    private String Description;

    private String Message;

    private String Symptom;

    private String SymptomId;

    private String Result;

    public String getStatus ()
    {
        return Status;
    }

    public void setStatus (String Status)
    {
        this.Status = Status;
    }

    public String getDescription ()
    {
        return Description;
    }

    public void setDescription (String Description)
    {
        this.Description = Description;
    }

    public String getMessage ()
    {
        return Message;
    }

    public void setMessage (String Message)
    {
        this.Message = Message;
    }

    public String getSymptom ()
    {
        return Symptom;
    }

    public void setSymptom (String Symptom)
    {
        this.Symptom = Symptom;
    }

    public String getSymptomId ()
    {
        return SymptomId;
    }

    public void setSymptomId (String SymptomId)
    {
        this.SymptomId = SymptomId;
    }

    public String getResult ()
    {
        return Result;
    }

    public void setResult (String Result)
    {
        this.Result = Result;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Status = "+Status+", Description = "+Description+", Message = "+Message+", Symptom = "+Symptom+", SymptomId = "+SymptomId+", Result = "+Result+"]";
    }
}
