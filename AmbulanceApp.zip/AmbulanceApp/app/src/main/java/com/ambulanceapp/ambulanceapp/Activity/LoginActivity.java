package com.ambulanceapp.ambulanceapp.Activity;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.ambulanceapp.ambulanceapp.Prefrences.SharePrefrences;
import com.ambulanceapp.ambulanceapp.R;
import com.ambulanceapp.ambulanceapp.Responses.LoginResponse;
import com.ambulanceapp.ambulanceapp.Retro.Retro;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION
                }, 0);
            }
            return;
        }
        checkLogin();
        Button btnLogin = (Button) findViewById(R.id.btnLogin);
        final EditText txtEmail = (EditText) findViewById(R.id.txtEmail);
        final EditText txtPassword = (EditText) findViewById(R.id.txtPassword);

        ImageButton btnChangeIP = (ImageButton) findViewById(R.id.img_chnagip);

        btnChangeIP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            final Dialog d = new Dialog(LoginActivity.this);
            d.setTitle("Set IP");
            d.setContentView(R.layout.dialog);
            final EditText ip = (EditText) d.findViewById(R.id.ip);
            Button submit = (Button) d.findViewById(R.id.submit);
            String ipStr = SharePrefrences.getServerURL(LoginActivity.this);
            ip.setText(ipStr);
            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String str = ip.getText().toString();
                    SharePrefrences.setServerURL(LoginActivity.this, str);
                    d.dismiss();
                }
            });
            d.show();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = txtEmail.getText().toString();
                String password = txtPassword.getText().toString();

                if (email.equals(""))
                    Toast.makeText(LoginActivity.this, "Email cannot be empty", Toast.LENGTH_SHORT).show();
                else if (password.equals(""))
                    Toast.makeText(LoginActivity.this, "Password cannot be empty", Toast.LENGTH_SHORT).show();
//                else if (password.length() < 6)
//                    Toast.makeText(LoginActivity.this, "Password length should be greater than 6", Toast.LENGTH_SHORT).show();
                else
                {
                    doLogin(email, password);
                }
            }
        });
    }


    void checkLogin()
    {
        final boolean isLogin = getSharedPreferences("key_prefereance", MODE_PRIVATE).getBoolean("key_islogin", false);
        if (isLogin) {
            startActivity(new Intent(getApplicationContext(), HomeActivity.class));
            //finish();
        }
    }


    private void doLogin(String email, String password) {

        final ProgressDialog progressDialog=new ProgressDialog(LoginActivity.this);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        try
        {
            Retro.getInterface(LoginActivity.this).loginAmbulance(email, password,new Callback<LoginResponse>() {
                @Override
                public void success(LoginResponse loginResponse, Response response) {
                    progressDialog.dismiss();
                    System.out.println(loginResponse.getStatus());
                    if (loginResponse.getStatus().equals("Success")) {
                        SharePrefrences.loginUser(LoginActivity.this,  loginResponse.getId(),loginResponse.getMobileNumber(),true);

                        Toast.makeText(LoginActivity.this,SharePrefrences.getUserId(LoginActivity.this), Toast.LENGTH_SHORT).show();

                        startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                        finish();
                    }
                    else {
                        Toast.makeText(LoginActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                    }
                }
                @Override
                public void failure(RetrofitError error) {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, "Check API", Toast.LENGTH_SHORT).show();
                }
            });
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}