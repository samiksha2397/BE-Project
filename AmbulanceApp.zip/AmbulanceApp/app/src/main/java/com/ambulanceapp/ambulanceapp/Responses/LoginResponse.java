package com.ambulanceapp.ambulanceapp.Responses;

public class LoginResponse {

    private String Status;

    private String MobileNumber;

    private String Lng;

    private String Id;

    private String Lat;

    private String Password;

    public String getStatus ()
    {
        return Status;
    }

    public void setStatus (String Status)
    {
        this.Status = Status;
    }

    public String getMobileNumber ()
    {
        return MobileNumber;
    }

    public void setMobileNumber (String MobileNumber)
    {
        this.MobileNumber = MobileNumber;
    }

    public String getLng ()
    {
        return Lng;
    }

    public void setLng (String Lng)
    {
        this.Lng = Lng;
    }

    public String getId ()
    {
        return Id;
    }

    public void setId (String Id)
    {
        this.Id = Id;
    }

    public String getLat ()
    {
        return Lat;
    }

    public void setLat (String Lat)
    {
        this.Lat = Lat;
    }

    public String getPassword ()
    {
        return Password;
    }

    public void setPassword (String Password)
    {
        this.Password = Password;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Status = "+Status+", MobileNumber = "+MobileNumber+", Lng = "+Lng+", Id = "+Id+", Lat = "+Lat+", Password = "+Password+"]";
    }

}
