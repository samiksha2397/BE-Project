package com.ambulanceapp.ambulanceapp.Responses;

public class GetPatientResponse {
    private String Status;

    private String AmbulanceAssigned;

    private String UserId;

    private String AcceptedBy;

    private String Time;

    private String Id;


    public String getUserLat() {
        return UserLat;
    }

    public void setUserLat(String userLat) {
        UserLat = userLat;
    }

    public String getUserLng() {
        return UserLng;
    }

    public void setUserLng(String userLng) {
        UserLng = userLng;
    }

    public String getHosLat() {
        return HosLat;
    }

    public void setHosLat(String hosLat) {
        HosLat = hosLat;
    }

    public String getHosLng() {
        return HosLng;
    }

    public void setHosLng(String hosLng) {
        HosLng = hosLng;
    }

    private String UserLat;
    private String UserLng;
    private String HosLat;
    private String HosLng;


    public String getStatus ()
    {
        return Status;
    }

    public void setStatus (String Status)
    {
        this.Status = Status;
    }

    public String getAmbulanceAssigned ()
    {
        return AmbulanceAssigned;
    }

    public void setAmbulanceAssigned (String AmbulanceAssigned)
    {
        this.AmbulanceAssigned = AmbulanceAssigned;
    }

    public String getUserId ()
    {
        return UserId;
    }

    public void setUserId (String UserId)
    {
        this.UserId = UserId;
    }

    public String getAcceptedBy ()
    {
        return AcceptedBy;
    }

    public void setAcceptedBy (String AcceptedBy)
    {
        this.AcceptedBy = AcceptedBy;
    }

    public String getTime ()
    {
        return Time;
    }

    public void setTime (String Time)
    {
        this.Time = Time;
    }

    public String getId ()
    {
        return Id;
    }

    public void setId (String Id)
    {
        this.Id = Id;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Status = "+Status+", AmbulanceAssigned = "+AmbulanceAssigned+", UserId = "+UserId+", AcceptedBy = "+AcceptedBy+", Time = "+Time+", Id = "+Id+"]";
    }
}
