package com.patienthealth.patienthealth.Retro;

import android.content.Context;
import android.util.Log;

import com.patienthealth.patienthealth.Prefrences.SharePrefrences;
import com.patienthealth.patienthealth.Responses.DiagnoseResponse;
import com.patienthealth.patienthealth.Responses.DietPlanResponse;
import com.patienthealth.patienthealth.Responses.GenralResponse;
import com.patienthealth.patienthealth.Responses.GetAmbulanceResponse;
import com.patienthealth.patienthealth.Responses.GetDashboardResponse;
import com.patienthealth.patienthealth.Responses.GetIssueResponse;
import com.patienthealth.patienthealth.Responses.LoginResponse;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.http.Field;
import retrofit.http.FormUrlEncoded;
import retrofit.http.Multipart;
import retrofit.http.POST;
import retrofit.http.Part;
import retrofit.mime.TypedFile;

public class Retro {

    public static String BASE_URL = "http://137.59.66.197:8081/PIS/API.asmx/";



    public static RestAdapter getClient(Context context) {

        SharePrefrences shareprefrance = new SharePrefrences();
        BASE_URL = "http://" + shareprefrance.getServerURL(context) + "/api.asmx/";

        Log.e("Retro", " BASE URL AS " + BASE_URL);

        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(BASE_URL)
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();
        return adapter;
    }



    public static Retrointerface getInterface(Context context) {
        return getClient(context).create(Retrointerface.class);
    }


    public interface Retrointerface{

        @FormUrlEncoded
        @POST("/login")
        public void login(
                @Field("Mobile") String Mobile,
                @Field("Password") String password,
                Callback<LoginResponse> response);


        @FormUrlEncoded
        @POST("/registerUser")
        public void registerUser(
                @Field("password") String password,
                @Field("name") String name,
                @Field("phone") String phone,
                @Field("address") String address,
                @Field("Email") String Email,
                @Field("Age") String Age,
                @Field("Gender") String Gender,
                @Field("BloodGroup") String BloodGroup,
                @Field("Weight") String Weight,
                @Field("Height") String Height,
                @Field("Diabeties") String Diabeties,
                @Field("BloodPressureIssue") String BloodPressureIssue,
                @Field("MedicalNote") String MedicalNote,
                @Field("EmergencyContact") String EmergencyContact,
                @Field("Allergy") String Allergy,

                Callback<GenralResponse> response);


        @FormUrlEncoded
        @POST("/updateLocation")
        public void updateLocation(
                @Field("id") int id,
                @Field("lat") double name,
                @Field("lng") double phone,
                Callback<GenralResponse> response);


        @FormUrlEncoded
        @POST("/GetIssue")
        public void GetIssue(
                @Field("id") int id,
                Callback<GetIssueResponse> response);

        @FormUrlEncoded
        @POST("/needHelp")
        public void needHelp(
                @Field("id") int id,
                Callback<GetIssueResponse> response);


        @FormUrlEncoded
        @POST("/GetAmbulance")
        public void GetAmbulance(
                @Field("userId") String id,
                Callback<GetAmbulanceResponse> response);



        @FormUrlEncoded
        @POST("/getDashboard")
        public void getDashboard(
                @Field("userId") String id,
                Callback<GetDashboardResponse> response);


        @FormUrlEncoded
        @POST("/Diagnose")
        public void Diagnose(
                @Field("Symptoms") String Symptoms,
                Callback<DiagnoseResponse> response);

        @Multipart
        @POST("/uploadPrescription")
        public void uploadPrescription(
                @Part("File") TypedFile file,
                Callback<GenralResponse> response);

        @FormUrlEncoded
        @POST("/getDietPlan")
        public void getDietPlan(
                @Field("userId") String id,
                Callback<DietPlanResponse> response);
    }
}
