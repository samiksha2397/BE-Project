package com.patienthealth.patienthealth.Responses;

public class GetAmbulanceResponse {
    private String Status;

    private String AmbulanceAssigned;

    private String MobileNumber;

    private String Lng;

    private String UserId;

    private String Id1;

    private String AcceptedBy;

    private String Time;

    private String Id;

    private String Lat;

    private String Password;

    public String getStatus ()
    {
        return Status;
    }

    public void setStatus (String Status)
    {
        this.Status = Status;
    }

    public String getAmbulanceAssigned ()
    {
        return AmbulanceAssigned;
    }

    public void setAmbulanceAssigned (String AmbulanceAssigned)
    {
        this.AmbulanceAssigned = AmbulanceAssigned;
    }

    public String getMobileNumber ()
    {
        return MobileNumber;
    }

    public void setMobileNumber (String MobileNumber)
    {
        this.MobileNumber = MobileNumber;
    }

    public String getLng ()
    {
        return Lng;
    }

    public void setLng (String Lng)
    {
        this.Lng = Lng;
    }

    public String getUserId ()
    {
        return UserId;
    }

    public void setUserId (String UserId)
    {
        this.UserId = UserId;
    }

    public String getId1 ()
    {
        return Id1;
    }

    public void setId1 (String Id1)
    {
        this.Id1 = Id1;
    }

    public String getAcceptedBy ()
    {
        return AcceptedBy;
    }

    public void setAcceptedBy (String AcceptedBy)
    {
        this.AcceptedBy = AcceptedBy;
    }

    public String getTime ()
    {
        return Time;
    }

    public void setTime (String Time)
    {
        this.Time = Time;
    }

    public String getId ()
    {
        return Id;
    }

    public void setId (String Id)
    {
        this.Id = Id;
    }

    public String getLat ()
    {
        return Lat;
    }

    public void setLat (String Lat)
    {
        this.Lat = Lat;
    }

    public String getPassword ()
    {
        return Password;
    }

    public void setPassword (String Password)
    {
        this.Password = Password;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Status = "+Status+", AmbulanceAssigned = "+AmbulanceAssigned+", MobileNumber = "+MobileNumber+", Lng = "+Lng+", UserId = "+UserId+", Id1 = "+Id1+", AcceptedBy = "+AcceptedBy+", Time = "+Time+", Id = "+Id+", Lat = "+Lat+", Password = "+Password+"]";
    }
}
