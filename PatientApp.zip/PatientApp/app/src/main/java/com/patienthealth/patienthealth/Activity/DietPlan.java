package com.patienthealth.patienthealth.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.patienthealth.patienthealth.Prefrences.SharePrefrences;
import com.patienthealth.patienthealth.R;
import com.patienthealth.patienthealth.Responses.DietPlanResponse;
import com.patienthealth.patienthealth.Responses.LoginResponse;
import com.patienthealth.patienthealth.Retro.Retro;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class DietPlan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_plan);


        final TextView txtDietPlan = (TextView) findViewById(R.id.txtDietPlan);

        final ProgressDialog progressDialog=new ProgressDialog(DietPlan.this);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        try
        {
            String UserId=SharePrefrences.getUserId(DietPlan.this);
            Retro.getInterface(DietPlan.this).getDietPlan(UserId,new Callback<DietPlanResponse>() {
                @Override
                public void success(DietPlanResponse Res, Response response) {
                    progressDialog.dismiss();
                    System.out.println(Res.getStatus());
                    if (Res.getStatus().equals("Success")) {
                       txtDietPlan.setText(Res.getDietPlan());
                    }
                    else {
                        Toast.makeText(DietPlan.this, "Error", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    progressDialog.dismiss();
                    Toast.makeText(DietPlan.this, "Check API", Toast.LENGTH_SHORT).show();
                }
            });

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }
}
