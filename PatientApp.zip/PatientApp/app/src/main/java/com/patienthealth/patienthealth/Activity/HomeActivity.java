package com.patienthealth.patienthealth.Activity;

import android.Manifest;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.patienthealth.patienthealth.Prefrences.SharePrefrences;
import com.patienthealth.patienthealth.R;
import com.patienthealth.patienthealth.Responses.GetAmbulanceResponse;
import com.patienthealth.patienthealth.Responses.GetIssueResponse;
import com.patienthealth.patienthealth.Responses.LoginResponse;
import com.patienthealth.patienthealth.Retro.Retro;
import com.patienthealth.patienthealth.Service.ServiceUpdateLocation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class HomeActivity extends AppCompatActivity{


    private HomeActivity context;
    int secsRemaining=0;
    Button btnSkip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        context=HomeActivity.this;

       // final EditText txtEmail = (EditText) findViewById(R.id.txtEmail);
        //final EditText txtPassword = (EditText) findViewById(R.id.txtPassword);
        //TextView btnRegister = (TextView) findViewById(R.id.btnRegister);
        btnSkip = (Button) findViewById(R.id.btnSkip);
        Button btnSOS = (Button) findViewById(R.id.btnSOS);

        btnSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharePrefrences.setIsSkipped(HomeActivity.this, true);
                finish();
            }
        });


        btnSOS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharePrefrences.setIsSkipped(HomeActivity.this, true);
                stoptimertask();
                ReportSOS();
                GetAmbulance();
            }
        });


        if (getIntent().getExtras() != null) {
            Bundle b = getIntent().getExtras();
            boolean cameFromNotification = b.getBoolean("fromNotification");

            if(cameFromNotification)
            {
                String ns = Context.NOTIFICATION_SERVICE;
                NotificationManager nMgr = (NotificationManager) HomeActivity.this.getSystemService(ns);
                nMgr.cancel(0);
                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                try {
                    Date date = formatter.parse(SharePrefrences.getSosTime(HomeActivity.this));
                    Date Now = new Date();
                    secsRemaining=(20- (int) ((Now.getTime()-date.getTime())/1000));
                    btnSkip.setText("Skip in "+secsRemaining+" secs");
                    startTimer();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }

        }
    }



    void ReportSOS()
    {
        final int UserId = Integer.parseInt(getSharedPreferences("key_prefereance", MODE_PRIVATE).getString("key_id", "-1"));
        Retro.getInterface(HomeActivity.this).needHelp(UserId,new Callback<GetIssueResponse>() {
            @Override
            public void success(GetIssueResponse GenResponse, Response response) {
                System.out.println(GenResponse.getStatus());
                if (GenResponse.getStatus().equals("Success")) {
                    Toast.makeText(HomeActivity.this, "Help Requested", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(HomeActivity.this, "API issue for SOS", Toast.LENGTH_SHORT).show();

                    // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                }
            }
            @Override
            public void failure(RetrofitError error) {
            }
        });

    }
    ProgressDialog progressDialog;
    private void GetAmbulance() {
        if(progressDialog==null)
        {
            progressDialog=new ProgressDialog(HomeActivity.this);
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }
        try
        {
            String UserId=SharePrefrences.getUserId(HomeActivity.this);
            Retro.getInterface(HomeActivity.this).GetAmbulance(UserId,new Callback<GetAmbulanceResponse>() {
                @Override
                public void success(GetAmbulanceResponse RResponse, Response response) {

                    System.out.println(RResponse.getStatus());
                    if (RResponse.getStatus().equals("Success")&&RResponse.getAmbulanceAssigned()!=null) {
                        progressDialog.dismiss();
                        startActivity(new Intent(HomeActivity.this, AmbulanceActivity.class));
                        finish();
                    }
                    else {
                        final Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // Do something after 5s = 5000ms
                                GetAmbulance();
                            }
                        }, 2000);

                        //progressDialog.dismiss();
                        // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    progressDialog.dismiss();
                    Toast.makeText(HomeActivity.this, "Check API", Toast.LENGTH_SHORT).show();
                }
            });

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }


    public void stoptimertask() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    private Timer timer;
    private TimerTask timerTask;
    public void startTimer() {
        //set a new Timer
        timer = new Timer();
        initializeTimerTask();
        timer.schedule(timerTask, 1000, 1000); //
    }


    public void initializeTimerTask() {
        timerTask = new TimerTask() {
            public void run() {
                try
                {
                    HomeActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            secsRemaining=secsRemaining-1;
                            if(secsRemaining>=0)
                            {
                                btnSkip.setText("Skip in "+secsRemaining+" secs");
                            }
                        }
                    });
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        };
    }
}
