package com.patienthealth.patienthealth.Service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.patienthealth.patienthealth.Activity.HomeActivity;
import com.patienthealth.patienthealth.Prefrences.SharePrefrences;
import com.patienthealth.patienthealth.Responses.GenralResponse;
import com.patienthealth.patienthealth.Responses.GetIssueResponse;
import com.patienthealth.patienthealth.Retro.Retro;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import com.patienthealth.patienthealth.R;

/**
 * Created by fabio on 30/01/2016.
 */
public class ServiceUpdateLocation extends Service implements   LocationListener{
    private LocationManager locationManager;
       private Timer timer;
    private TimerTask timerTask;


    //---------------------------------------------------------------------------------------
    public ServiceUpdateLocation(Context applicationContext) {
        super();
        Log.e("ServiceAtul", "here I am!");
    }

    public ServiceUpdateLocation() {
    }

    //---------------------------------------------------------------------------------------
    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("ServiceAtul", "here I am!");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        locationManager = (LocationManager) ServiceUpdateLocation.this.getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);

        startTimer();
        Log.e("ServiceAtul", "UpdateLocation Called");
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("ServiceAtul", "ondestroy!");
        Intent broadcastIntent = new Intent("uk.ac.shef.oak.ActivityRecognition.RestartSensor");
        sendBroadcast(broadcastIntent);
        locationManager.removeUpdates(this);
        stoptimertask();
    }

    public void startTimer() {
        //set a new Timer
        timer = new Timer();

        //initialize the TimerTask's job
        initializeTimerTask();

        //schedule the timer, to wake up every 10 minutus
        timer.schedule(timerTask, 1000, 3000); //
    }

    void updateLocation()
    {
        if(latitude!=0)
        {
            final int UserId = Integer.parseInt(getSharedPreferences("key_prefereance", MODE_PRIVATE).getString("key_id", "-1"));
            Retro.getInterface(ServiceUpdateLocation.this).updateLocation(UserId, latitude,longitude,new Callback<GenralResponse>() {
                @Override
                public void success(GenralResponse GenResponse, Response response) {
                    System.out.println(GenResponse.getStatus());
                    if (GenResponse.getStatus().equals("Success")) {

                    }
                    else {
                        //Toast.makeText(ServiceUpdateLocation.this, "Login Failed", Toast.LENGTH_SHORT).show();

                        // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                    }
                }
                @Override
                public void failure(RetrofitError error) {
                }
            });
        }
    }

    void GetIssues()
    {
        final int UserId = Integer.parseInt(getSharedPreferences("key_prefereance", MODE_PRIVATE).getString("key_id", "-1"));
        Retro.getInterface(ServiceUpdateLocation.this).GetIssue(UserId,new Callback<GetIssueResponse>() {
            @Override
            public void success(GetIssueResponse GenResponse, Response response) {
                System.out.println(GenResponse.getStatus());
                if (GenResponse.getStatus().equals("Success")) {
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                    Date date = new Date();
                    SharePrefrences.setSosTime(ServiceUpdateLocation.this ,formatter.format(date));;
                    SharePrefrences.setIsSkipped(ServiceUpdateLocation.this, false);
                    addNotification("Health Issue detected: "+GenResponse. getSymptom(),GenResponse.getDescription());
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                        if(!SharePrefrences.getIsSkipped(ServiceUpdateLocation.this))
                        {
                            ReportSOS();
                        }
                        }
                    }, 20000);
                }
                else {
                    //Toast.makeText(ServiceUpdateLocation.this, "API issue for GetIssue", Toast.LENGTH_SHORT).show();
                    // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                }
            }
            @Override
            public void failure(RetrofitError error) {
                Toast.makeText(ServiceUpdateLocation.this, "API issue for GetIssue", Toast.LENGTH_SHORT).show();
            }
        });
    }


    void ReportSOS()
    {
        final int UserId = Integer.parseInt(getSharedPreferences("key_prefereance", MODE_PRIVATE).getString("key_id", "-1"));
        Retro.getInterface(ServiceUpdateLocation.this).needHelp(UserId,new Callback<GetIssueResponse>() {
            @Override
            public void success(GetIssueResponse GenResponse, Response response) {
                System.out.println(GenResponse.getStatus());
                if (GenResponse.getStatus().equals("Success")) {
                    Toast.makeText(ServiceUpdateLocation.this, "Help Requested", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(ServiceUpdateLocation.this, "API issue for SOS", Toast.LENGTH_SHORT).show();

                    // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                }
            }
            @Override
            public void failure(RetrofitError error) {
            }
        });

    }
    public void initializeTimerTask() {
        timerTask = new TimerTask() {
            public void run() {
            try
            {
                updateLocation();
                if(!SharePrefrences.getIsExcerciseMode(ServiceUpdateLocation.this))
                {
                    GetIssues();
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            }
        };
    }

    private void addNotification(String title,String Text) {
//        NotificationCompat.Builder builder =
//                new NotificationCompat.Builder(this)
//                        .setSmallIcon(R.drawable.health_alert)
//                        .setContentTitle(title)
//                        .setContentText(Text);
//
//        Intent notificationIntent = new Intent(this, HomeActivity.class);
//        notificationIntent.putExtra("fromNotification", true);
//
//        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent,
//                PendingIntent.FLAG_UPDATE_CURRENT);
//        builder.setContentIntent(contentIntent);
//
//        // Add as notification
//        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//        //notificationIntent.putExtra("Id", 0);
//        manager.notify(0, builder.build());
//        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//        builder.setSound(alarmSound);


        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(ServiceUpdateLocation.this.getApplicationContext(), "notify_001");
        Intent ii = new Intent(this, HomeActivity.class);
        ii.putExtra("fromNotification", true);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, ii, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.BigTextStyle bigText = new NotificationCompat.BigTextStyle();
        bigText.bigText(Text);
        bigText.setBigContentTitle(title);
        //bigText.setSummaryText("Text in detail");

        mBuilder.setContentIntent(pendingIntent);
        mBuilder.setSmallIcon(R.drawable.health_alert);
        mBuilder.setContentTitle(title);
        mBuilder.setContentText(Text);
        mBuilder.setPriority(Notification.PRIORITY_MAX);
        mBuilder.setStyle(bigText);

        NotificationManager mNotificationManager =
                (NotificationManager) ServiceUpdateLocation.this.getSystemService(Context.NOTIFICATION_SERVICE);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("notify_001",
                    "Channel human readable title",
                    NotificationManager.IMPORTANCE_DEFAULT);
            mNotificationManager.createNotificationChannel(channel);
        }

        mNotificationManager.notify(0, mBuilder.build());
    }

    /**
     * not needed
     */
    public void stoptimertask() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Date yesterday() {
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }

    private double speed=0, latitude=0.0, longitude=0.0;
    // This method is called whenever new location data is available
    @Override
    public void onLocationChanged(Location location) {

        Log.e("Location","Location updated");
        // get location data
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        speed =(location.getSpeed())*(18/5);
        //txtSpeed.setText(Math.round( speed)+" Kmph");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onProviderEnabled(String provider) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onProviderDisabled(String provider) {
        // TODO Auto-generated method stub
    }

    float potholeWarningDistance = 20.0f;
    private static int counter;
    TextToSpeech tts;
}