package com.patienthealth.patienthealth.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.patienthealth.patienthealth.Prefrences.SharePrefrences;
import com.patienthealth.patienthealth.Responses.GetAmbulanceResponse;
import com.patienthealth.patienthealth.Retro.Retro;
import com.patienthealth.patienthealth.R;

import java.util.Timer;
import java.util.TimerTask;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class AmbulanceActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private Marker mark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ambulance);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera

        startTimer();
    }


    private Timer timer;
    private TimerTask timerTask;

    public void startTimer() {
        //set a new Timer
        timer = new Timer();

        //initialize the TimerTask's job
        initializeTimerTask();

        //schedule the timer, to wake up every 10 minutus
        timer.schedule(timerTask, 1000, 10000); //
    }


    public void initializeTimerTask() {
        timerTask = new TimerTask() {
            public void run() {
            try
            {
                GetAmbulance();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            }
        };
    }


    private void GetAmbulance() {

        try
        {
            String UserId= SharePrefrences.getUserId(AmbulanceActivity.this);
            Retro.getInterface(AmbulanceActivity.this).GetAmbulance(UserId,new Callback<GetAmbulanceResponse>() {
                @Override
                public void success(GetAmbulanceResponse RResponse, Response response) {

                    System.out.println(RResponse.getStatus());
                    if (RResponse.getStatus().equals("Success")) {
                        if(mark!=null)
                        {
                            mark.remove();
                        }

                        LatLng ltlng = new LatLng(Double.parseDouble(RResponse.getLat()),Double.parseDouble(RResponse.getLng()));
                        //mMap.addMarker(new MarkerOptions().position(v).title("Ambulance"));
                        mark=mMap.addMarker(new MarkerOptions().position(ltlng).icon(BitmapDescriptorFactory.fromResource((R.drawable.ambulance))).title("Ambulance"));
                        LatLngBounds.Builder builder = new LatLngBounds.Builder();
                        builder.include(ltlng);
                        //mMap.moveCamera(CameraUpdateFactory.newLatLng(ltlng));
                        LatLngBounds bounds = builder.build();
                        int padding = 50;
                        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                        mMap.animateCamera(cu);
                    }
                    else {
                        //GetAmbulance();
                        //progressDialog.dismiss();
                        // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                    }
                }

                @Override
                public void failure(RetrofitError error) {

                    Toast.makeText(AmbulanceActivity.this, "Check API", Toast.LENGTH_SHORT).show();
                }
            });

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}
