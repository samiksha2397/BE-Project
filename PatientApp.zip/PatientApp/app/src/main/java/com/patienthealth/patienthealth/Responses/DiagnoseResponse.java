package com.patienthealth.patienthealth.Responses;

public class DiagnoseResponse {
    private String Status;

    private String Message;

    private String Symptom;

    private String Result;

    public String getStatus ()
    {
        return Status;
    }

    public void setStatus (String Status)
    {
        this.Status = Status;
    }

    public String getMessage ()
    {
        return Message;
    }

    public void setMessage (String Message)
    {
        this.Message = Message;
    }

    public String getSymptom ()
    {
        return Symptom;
    }

    public void setSymptom (String Symptom)
    {
        this.Symptom = Symptom;
    }

    public String getResult ()
    {
        return Result;
    }

    public void setResult (String Result)
    {
        this.Result = Result;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Status = "+Status+", Message = "+Message+", Symptom = "+Symptom+", Result = "+Result+"]";
    }
}
