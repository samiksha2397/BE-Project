package com.patienthealth.patienthealth.Responses;

public class DietPlanResponse {

    private String Status;

    private String BMIMax;

    private String Id;

    private String BMIMin;

    private String DietPlan;

    public String getStatus ()
    {
        return Status;
    }

    public void setStatus (String Status)
    {
        this.Status = Status;
    }

    public String getBMIMax ()
    {
        return BMIMax;
    }

    public void setBMIMax (String BMIMax)
    {
        this.BMIMax = BMIMax;
    }

    public String getId ()
    {
        return Id;
    }

    public void setId (String Id)
    {
        this.Id = Id;
    }

    public String getBMIMin ()
    {
        return BMIMin;
    }

    public void setBMIMin (String BMIMin)
    {
        this.BMIMin = BMIMin;
    }

    public String getDietPlan ()
    {
        return DietPlan;
    }

    public void setDietPlan (String DietPlan)
    {
        this.DietPlan = DietPlan;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Status = "+Status+", BMIMax = "+BMIMax+", Id = "+Id+", BMIMin = "+BMIMin+", DietPlan = "+DietPlan+"]";
    }
}
