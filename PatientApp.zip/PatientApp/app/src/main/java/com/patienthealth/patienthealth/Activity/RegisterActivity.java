package com.patienthealth.patienthealth.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.patienthealth.patienthealth.R;
import com.patienthealth.patienthealth.Responses.GenralResponse;
import com.patienthealth.patienthealth.Retro.Retro;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class RegisterActivity extends AppCompatActivity {

    EditText txtPassword;
    EditText txtCity;
    EditText txtMobile;
    EditText txtName;
    private EditText txtEmail;
    private EditText txtAge;
    private EditText txtWeight;
    private EditText txtHeight;
    private EditText txtBloodGroup;
    private EditText txtAllergy;
    private EditText txtMedNote;
    private EditText txtEmergencyContactNumber;
    private Spinner cmbGender;
    private Spinner cmbIsBloodPressureIssue;
    private Spinner cmbIsDiabetic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        Button btnRegister = (Button) findViewById(R.id.btnRegister);

        txtPassword = (EditText) findViewById(R.id.txtPassword);
        txtCity = (EditText) findViewById(R.id.txtCity);
        txtMobile = (EditText) findViewById(R.id.txtMobile);
        txtName = (EditText) findViewById(R.id.txtName);
        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtAge = (EditText) findViewById(R.id.txtAge);
        txtWeight = (EditText) findViewById(R.id.txtWeight);
        txtHeight = (EditText) findViewById(R.id.txtHeight);
        txtBloodGroup = (EditText) findViewById(R.id.txtBloodGroup);
        txtAllergy = (EditText) findViewById(R.id.txtAllergy);
        txtMedNote = (EditText) findViewById(R.id.txtMedNote);

        txtEmergencyContactNumber = (EditText) findViewById(R.id.txtEmergencyContactNumber);
        cmbGender = (Spinner) findViewById(R.id.cmbGender);
        cmbIsBloodPressureIssue = (Spinner) findViewById(R.id.cmbIsBloodPressureIssue);
         cmbIsDiabetic = (Spinner) findViewById(R.id.cmbIsDiabetic);



        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RegisterUser();
            }
        });
    }

    void RegisterUser()
    {
        final ProgressDialog progressDialog=new ProgressDialog(RegisterActivity.this);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        try
        {
            Retro.getInterface(RegisterActivity.this).registerUser
                    (txtPassword.getText().toString(),
                            txtName.getText().toString(),
                            txtMobile.getText().toString(),
                            txtCity.getText().toString(),
                            txtEmail.getText().toString(),
                            txtAge.getText().toString(),
                            cmbGender.getSelectedItem().toString(),
                            txtBloodGroup.getText().toString(),
                            txtWeight.getText().toString(),
                            txtHeight.getText().toString(),
                            cmbIsDiabetic.getSelectedItem().toString(),
                            cmbIsBloodPressureIssue.getSelectedItem().toString(),
                            txtMedNote.getText().toString(),
                            txtEmergencyContactNumber.getText().toString(),
                            txtAllergy.getText().toString(),
                            new Callback<GenralResponse>() {
                @Override
                public void success(GenralResponse Response, Response response) {
                    progressDialog.dismiss();
                    System.out.println(Response.getStatus());
                    if (Response.getStatus().equals("Success")) {
                        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                        finish();
                    }

                    else {
                        Toast.makeText(RegisterActivity.this, Response.getMessage(), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    progressDialog.dismiss();
                    Toast.makeText(RegisterActivity.this, "Check API", Toast.LENGTH_SHORT).show();
                }
            });

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}