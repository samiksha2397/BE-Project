package com.patienthealth.patienthealth.Activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.patienthealth.patienthealth.Prefrences.SharePrefrences;
import com.patienthealth.patienthealth.R;
import com.patienthealth.patienthealth.Responses.GenralResponse;
import com.patienthealth.patienthealth.Responses.GetDashboardResponse;
import com.patienthealth.patienthealth.Responses.GetIssueResponse;
import com.patienthealth.patienthealth.Retro.Retro;
import com.patienthealth.patienthealth.Service.ServiceUpdateLocation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedFile;

public class DashboardActivity extends AppCompatActivity {
    private TextView txtTemprature;
    private TextView txtHearRate;
    static final int REQUEST_IMAGE_CAPTURE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        txtTemprature = (TextView) findViewById(R.id.txtTemprature);
        txtHearRate = (TextView) findViewById(R.id.txtHearRate);

        startService(new Intent(DashboardActivity.this, ServiceUpdateLocation.class));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION
                }, 0);
            }
            return;
        }
        startTimer();

        Switch swtchExcercise = (Switch) findViewById(R.id.swtchExcercise);
        swtchExcercise.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharePrefrences.setIsExcerciseMode(DashboardActivity.this, isChecked);
            }
        });

        Button btnCheckSymptoms = (Button) findViewById(R.id.btnCheckSymptoms);
        btnCheckSymptoms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), CheckSymptomsActivity.class));
            }
        });

        Button btnDietPlan = (Button) findViewById(R.id.btnDietPlan);
        btnDietPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), DietPlan.class));
            }
        });


        Button btnUploadPrescription = (Button) findViewById(R.id.btnUploadPrescription);
        btnUploadPrescription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
            }
        });

        Button btnNeedHelp = (Button) findViewById(R.id.btnNeedHelp);
        btnNeedHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final ProgressDialog progressDialog = new ProgressDialog(DashboardActivity.this);
                progressDialog.setMessage("Please wait...");
                progressDialog.show();
                final int UserId = Integer.parseInt(getSharedPreferences("key_prefereance", MODE_PRIVATE).getString("key_id", "-1"));
                Retro.getInterface(DashboardActivity.this).needHelp(UserId, new Callback<GetIssueResponse>() {
                    @Override
                    public void success(GetIssueResponse GenResponse, Response response) {
                        progressDialog.dismiss();
                        System.out.println(GenResponse.getStatus());
                        if (GenResponse.getStatus().equals("Success")) {
                            Toast.makeText(DashboardActivity.this, "Help Requested", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(DashboardActivity.this, "API issue for SOS", Toast.LENGTH_SHORT).show();

                            // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                        }
                    }

                    @Override
                    public void failure(RetrofitError error) {
                        progressDialog.dismiss();
                    }
                });
            }
        });
    }


    private static final String ALLOWED_CHARACTERS = "0123456789qwertyuiopasdfghjklzxcvbnm";

    private static String getRandomString(final int sizeOfRandomString) {
        final Random random = new Random();
        final StringBuilder sb = new StringBuilder(sizeOfRandomString);
        for (int i = 0; i < sizeOfRandomString; ++i)
            sb.append(ALLOWED_CHARACTERS.charAt(random.nextInt(ALLOWED_CHARACTERS.length())));
        return sb.toString();
    }

    String FileType = "image";
    private Uri uri;
    File file;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            FileType = "image";
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");

            String FileName = getRandomString(10);
            file = new File(DashboardActivity.this.getCacheDir(), FileName + ".jpg");
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }

//Convert bitmap to byte array

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100 /*ignored for PNG*/, bos);
            byte[] bitmapdata = bos.toByteArray();

//write the bytes in file
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(file);
                fos.write(bitmapdata);
                fos.flush();
                fos.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            uploadPrescription();
        }
    }


    void uploadPrescription()
    {
        final ProgressDialog progressDialog=new ProgressDialog(DashboardActivity.this);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        try
        {
            TypedFile typedFile = new TypedFile("multipart/form-data", file);
            //String User= SharePrefrences.getUserId(context);


            Retro.getInterface(DashboardActivity.this).uploadPrescription(typedFile,new Callback<GenralResponse>() {
                @Override
                public void success(GenralResponse res, Response response) {
                    progressDialog.dismiss();
                    System.out.println(res.getStatus());
                    if (res.getStatus().equals("Success")) {
                        Toast.makeText(DashboardActivity.this, "Prescription uploaded successfully.", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else {
                        Toast.makeText(DashboardActivity.this, "Report upload Failed cause:"+res.getMessage(), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    Toast.makeText(DashboardActivity.this, "Please check you API Connection", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            });
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }


    }

    void GetHardwareValues()
    {
        try
        {
            String UserId=SharePrefrences.getUserId(DashboardActivity.this);
            Retro.getInterface(DashboardActivity.this).getDashboard(UserId,new Callback<GetDashboardResponse>() {
                @Override
                public void success(GetDashboardResponse RResponse, Response response) {

                    if (RResponse.getStatus().equals("Success")) {
                        txtHearRate.setText(RResponse.getHeartRate());
                        txtTemprature.setText(RResponse.getTemp());
                        //txtRain.setText(RResponse.getRain());
                    }
                    else {
                        Toast.makeText(DashboardActivity.this, "Hardware Values load Failed", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    Toast.makeText(DashboardActivity.this, "Please check you API Connection", Toast.LENGTH_SHORT).show();
                }
            });
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }



    private Timer timer;
    private TimerTask timerTask;
    public void startTimer() {
        //set a new Timer
        timer = new Timer();

        //initialize the TimerTask's job
        initializeTimerTask();

        //schedule the timer, to wake up every 10 minutus
        timer.schedule(timerTask, 1000, 5000); //
    }

    /**
     * it sets the timer to print the counter every x seconds
     */
    public void initializeTimerTask() {
        timerTask = new TimerTask() {
            public void run() {
                GetHardwareValues();
            }
        };
    }







}
