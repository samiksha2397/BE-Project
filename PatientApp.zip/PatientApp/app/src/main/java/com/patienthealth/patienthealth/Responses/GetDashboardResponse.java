package com.patienthealth.patienthealth.Responses;

public class GetDashboardResponse {
    private String Status;

    private String Allergy;

    private String EmergencyContact;

    private String HeartRate;

    private String Email;

    private String BloodGroup;

    private String MedicalNote;

    private String Address;

    private String Lng;

    private String Diabeties;

    private String BloodPressureIssue;

    private String Gender;

    private String Mobile;

    private String Weight;

    private String Name;

    private String Temp;

    private String Height;

    private String Id;

    private String Lat;

    private String Age;

    private String Password;

    public String getStatus ()
    {
        return Status;
    }

    public void setStatus (String Status)
    {
        this.Status = Status;
    }

    public String getAllergy ()
    {
        return Allergy;
    }

    public void setAllergy (String Allergy)
    {
        this.Allergy = Allergy;
    }

    public String getEmergencyContact ()
    {
        return EmergencyContact;
    }

    public void setEmergencyContact (String EmergencyContact)
    {
        this.EmergencyContact = EmergencyContact;
    }

    public String getHeartRate ()
    {
        return HeartRate;
    }

    public void setHeartRate (String HeartRate)
    {
        this.HeartRate = HeartRate;
    }

    public String getEmail ()
    {
        return Email;
    }

    public void setEmail (String Email)
    {
        this.Email = Email;
    }

    public String getBloodGroup ()
    {
        return BloodGroup;
    }

    public void setBloodGroup (String BloodGroup)
    {
        this.BloodGroup = BloodGroup;
    }

    public String getMedicalNote ()
    {
        return MedicalNote;
    }

    public void setMedicalNote (String MedicalNote)
    {
        this.MedicalNote = MedicalNote;
    }

    public String getAddress ()
    {
        return Address;
    }

    public void setAddress (String Address)
    {
        this.Address = Address;
    }

    public String getLng ()
    {
        return Lng;
    }

    public void setLng (String Lng)
    {
        this.Lng = Lng;
    }

    public String getDiabeties ()
    {
        return Diabeties;
    }

    public void setDiabeties (String Diabeties)
    {
        this.Diabeties = Diabeties;
    }

    public String getBloodPressureIssue ()
    {
        return BloodPressureIssue;
    }

    public void setBloodPressureIssue (String BloodPressureIssue)
    {
        this.BloodPressureIssue = BloodPressureIssue;
    }

    public String getGender ()
    {
        return Gender;
    }

    public void setGender (String Gender)
    {
        this.Gender = Gender;
    }

    public String getMobile ()
    {
        return Mobile;
    }

    public void setMobile (String Mobile)
    {
        this.Mobile = Mobile;
    }

    public String getWeight ()
    {
        return Weight;
    }

    public void setWeight (String Weight)
    {
        this.Weight = Weight;
    }

    public String getName ()
    {
        return Name;
    }

    public void setName (String Name)
    {
        this.Name = Name;
    }

    public String getTemp ()
    {
        return Temp;
    }

    public void setTemp (String Temp)
    {
        this.Temp = Temp;
    }

    public String getHeight ()
    {
        return Height;
    }

    public void setHeight (String Height)
    {
        this.Height = Height;
    }

    public String getId ()
    {
        return Id;
    }

    public void setId (String Id)
    {
        this.Id = Id;
    }

    public String getLat ()
    {
        return Lat;
    }

    public void setLat (String Lat)
    {
        this.Lat = Lat;
    }

    public String getAge ()
    {
        return Age;
    }

    public void setAge (String Age)
    {
        this.Age = Age;
    }

    public String getPassword ()
    {
        return Password;
    }

    public void setPassword (String Password)
    {
        this.Password = Password;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Status = "+Status+", Allergy = "+Allergy+", EmergencyContact = "+EmergencyContact+", HeartRate = "+HeartRate+", Email = "+Email+", BloodGroup = "+BloodGroup+", MedicalNote = "+MedicalNote+", Address = "+Address+", Lng = "+Lng+", Diabeties = "+Diabeties+", BloodPressureIssue = "+BloodPressureIssue+", Gender = "+Gender+", Mobile = "+Mobile+", Weight = "+Weight+", Name = "+Name+", Temp = "+Temp+", Height = "+Height+", Id = "+Id+", Lat = "+Lat+", Age = "+Age+", Password = "+Password+"]";
    }
}
