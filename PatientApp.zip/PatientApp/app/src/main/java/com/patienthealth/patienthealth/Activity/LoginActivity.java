package com.patienthealth.patienthealth.Activity;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.patienthealth.patienthealth.Prefrences.SharePrefrences;
import com.patienthealth.patienthealth.R;
import com.patienthealth.patienthealth.Responses.LoginResponse;
import com.patienthealth.patienthealth.Retro.Retro;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        checkLogin();
        Button btnLogin = (Button) findViewById(R.id.btnLogin);
        final EditText txtMobile = (EditText) findViewById(R.id.txtMobile);
        final EditText txtPassword = (EditText) findViewById(R.id.txtPassword);
        TextView btnRegister = (TextView) findViewById(R.id.btnRegister);
        ImageButton btnChangeIP = (ImageButton) findViewById(R.id.img_chnagip);


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this
                        , RegisterActivity.class);
                startActivity(intent);
            }
        });

        btnChangeIP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog d = new Dialog(LoginActivity.this);
                d.setTitle("Set IP");
                d.setContentView(R.layout.dialog);
                final EditText ip = (EditText) d.findViewById(R.id.ip);
                Button submit = (Button) d.findViewById(R.id.submit);
                String ipStr = SharePrefrences.getServerURL(LoginActivity.this);
                ip.setText(ipStr);
                submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String str = ip.getText().toString();
                        SharePrefrences.setServerURL(LoginActivity.this, str);
                        d.dismiss();
                    }
                });
                d.show();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mobile = txtMobile.getText().toString();
                String password = txtPassword.getText().toString();

                if (mobile.equals(""))
                    Toast.makeText(LoginActivity.this, "Mobile cannot be empty", Toast.LENGTH_SHORT).show();
                else if (password.equals(""))
                    Toast.makeText(LoginActivity.this, "Password cannot be empty", Toast.LENGTH_SHORT).show();
//                else if (password.length() < 6)
//                    Toast.makeText(LoginActivity.this, "Password length should be greater than 6", Toast.LENGTH_SHORT).show();
                else
                {
                    doLogin(mobile, password);
                }
            }
        });
    }


    void checkLogin()
    {
        final boolean isLogin = getSharedPreferences("key_prefereance", MODE_PRIVATE).getBoolean("key_islogin", false);
        if (isLogin) {
            startActivity(new Intent(getApplicationContext(), DashboardActivity.class));
            //finish();
        }
    }


    private void doLogin(String mobile,String password) {

        final ProgressDialog progressDialog=new ProgressDialog(LoginActivity.this);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        try
        {
            Retro.getInterface(LoginActivity.this).login(mobile, password,new Callback<LoginResponse>() {
                @Override
                public void success(LoginResponse loginResponse, Response response) {
                    progressDialog.dismiss();
                    System.out.println(loginResponse.getStatus());
                    if (loginResponse.getStatus().equals("Success")) {
                        SharePrefrences.loginUser(LoginActivity.this, loginResponse.getName(), loginResponse.getId(),loginResponse.getPhone(),loginResponse.getEmailId(),true);

                        Toast.makeText(LoginActivity.this,SharePrefrences.getUserId(LoginActivity.this),Toast.LENGTH_SHORT).show();

                        startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
                        finish();
                    }
                    else {
                        Toast.makeText(LoginActivity.this, loginResponse.getMessage(), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        // shareprefrance.loginUser(context, loginResponse.getName(), loginResponse.getId(), true);
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, "Check API", Toast.LENGTH_SHORT).show();
                }
            });

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}