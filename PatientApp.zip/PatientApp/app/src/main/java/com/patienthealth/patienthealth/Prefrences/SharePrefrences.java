package com.patienthealth.patienthealth.Prefrences;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class SharePrefrences {
    private static final String KEY_SERVER_URL = "key_server_url";
    private static final String KEY_PREFERANCE = "key_prefereance";
    private static final String KEY_NAME = "key_name";
    private static final String KEY_EMAIl = "key_email";
    private static final String KEY_PHONE = "key_phone";
    private static final String KEY_ISLOGIN = "key_islogin";
    private static final String KEY_ID = "key_id";
    private static final String Key_SosTime = "key_sos";
    private static final String Key_IsSkiped = "Key_IsSkiped";
    private static final String Key_IsExcerciseMode = "Key_IsExcerciseMode";

    public static void loginUser(Context context, String name, String userId, String mobile , String email, boolean isLogin) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_NAME, name);
        editor.putString(KEY_EMAIl, email);
        editor.putString(KEY_ID, userId);
        editor.putString(KEY_PHONE, mobile);
        editor.putBoolean(KEY_ISLOGIN, isLogin);
        editor.apply();
    }

    public static void setServerURL(Context context, String url) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_SERVER_URL, url);
        editor.apply();
    }

    public static void setSosTime(Context context, String SosTime) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(Key_SosTime, SosTime);
        editor.apply();
    }

    public static String getSosTime(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        Log.e("####", " Preferance IP as " + sharedPreferences.getString(KEY_SERVER_URL, ""));
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        return sharedPreferences.getString(Key_SosTime, formatter.format(date));
    }


    public static void setIsSkipped(Context context, Boolean IsSkiped) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(Key_IsSkiped, IsSkiped);
        editor.apply();
    }

    public static Boolean getIsSkipped(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        Log.e("####", " Preferance IP as " + sharedPreferences.getString(KEY_SERVER_URL, ""));
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        return sharedPreferences.getBoolean(Key_IsSkiped, false);
    }


    public static void setIsExcerciseMode(Context context, Boolean Mode) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(Key_IsExcerciseMode, Mode);
        editor.apply();
    }

    public static Boolean getIsExcerciseMode(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(Key_IsExcerciseMode, false);
    }




    public static String getServerURL(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        Log.e("####", " Preferance IP as " + sharedPreferences.getString(KEY_SERVER_URL, ""));
        return sharedPreferences.getString(KEY_SERVER_URL, "137.59.66.197:8081");
    }

    public static String getUserId(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_ID, "");
    }

    public static String getName(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_NAME, "");
    }

    public static String getEmailId(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_PREFERANCE, Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_EMAIl, "");
    }
}
