package com.patienthealth.patienthealth.Activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.patienthealth.patienthealth.Prefrences.SharePrefrences;
import com.patienthealth.patienthealth.R;
import com.patienthealth.patienthealth.Responses.DiagnoseResponse;
import com.patienthealth.patienthealth.Responses.GetDashboardResponse;
import com.patienthealth.patienthealth.Responses.GetIssueResponse;
import com.patienthealth.patienthealth.Retro.Retro;
import com.patienthealth.patienthealth.Service.ServiceUpdateLocation;

import java.util.Timer;
import java.util.TimerTask;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class CheckSymptomsActivity extends AppCompatActivity {
    private EditText txtSymptoms;
    private TextView lblDiagnose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_symptoms);
        txtSymptoms = (EditText)  findViewById(R.id.txtSymptoms);
        lblDiagnose = (TextView)  findViewById(R.id.lblDiagnose);

        Button btnCheckSymptoms = (Button) findViewById(R.id.btnCheckSymptoms);
        btnCheckSymptoms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ProgressDialog progressDialog=new ProgressDialog(CheckSymptomsActivity.this);
                progressDialog.setMessage("Please wait...");
                progressDialog.show();
                Retro.getInterface(CheckSymptomsActivity.this).Diagnose(txtSymptoms.getText().toString(),new Callback<DiagnoseResponse>() {
                    @Override
                    public void success(DiagnoseResponse GenResponse, Response response) {
                        progressDialog.dismiss();
                        System.out.println(GenResponse.getStatus());
                        if (GenResponse.getStatus().equals("Success")&&GenResponse.getResult().equals("Found")) {
                            lblDiagnose.setText("Issue Detected: "+GenResponse.getSymptom());                        }
                        else {
                            lblDiagnose.setText("Nothing serious Detected");
                            Toast.makeText(CheckSymptomsActivity.this, "Nothing Detected", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        progressDialog.dismiss();
                    }
                });
            }
       });
    }








}
